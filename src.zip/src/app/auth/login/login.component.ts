import { Component, OnInit } from '@angular/core';
import { RouterModule, Routes, Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginData: any = { email: '', password: '' };

  constructor(private router: Router) { }

  ngOnInit() {
  }

  login() {
    this.router.navigate(['/']);
  }

}
