import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './auth/login/login.component';
import { MainComponent } from './layout/main/main.component';
import { PostsComponent } from './posts/posts/posts.component';
import { EditorComponent } from './posts/editor/editor.component';
import { PostComponent } from './posts/post/post.component';
import { AuthGuardGuard } from './auth-guard.guard';
const routes: Routes = [
  {
    path: '', component: MainComponent,
    children: [
      { path: '', component: PostsComponent },
      { path: 'create', component: EditorComponent , canActivate: [AuthGuardGuard]},
      { path: 'posts', component: PostsComponent },
      { path: 'post/:id', component: PostComponent }
    ]
  },
  { path: 'login', component: LoginComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
