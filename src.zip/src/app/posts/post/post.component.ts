import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css']
})
export class PostComponent implements OnInit {

  id: any;
  constructor(private router: Router, private route: ActivatedRoute) { }

  ngOnInit() {
    //this.id = this.route.snapshot.paramMap.get('id');

    this.route.paramMap.subscribe((p) => {
      this.id = +p.get('id');
    });
  }

}
