import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EditorComponent } from './editor/editor.component';
import { PostComponent } from './post/post.component';
import { PostsComponent } from './posts/posts.component';

@NgModule({
  declarations: [EditorComponent, PostComponent, PostsComponent],
  imports: [
    CommonModule, FormsModule, ReactiveFormsModule
  ]
})
export class PostsModule { }
